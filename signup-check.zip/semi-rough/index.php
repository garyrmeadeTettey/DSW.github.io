<?php
   include_once("../db_connect.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Elevate.Self</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"> -->

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->

<header class="header">

   <section class="flex">

      <a href="index.php" class="logo">Elevate.Self</a>

      <nav class="navbar">
         <a href="index.php">home</a>
         <a href="index.php#about">about</a>
         <a href="textbook.php">Textbooks</a>
         <a href="index.php#teachers">Tutors</a>
         <a href="resources.php">Resources</a>
         <a href="index.php#contact">contact</a>
         <a href="logout.php">Logout</a>
      </nav>

      <div id="menu-btn" class="fas fa-bars"></div>

   </section>

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

   <div class="row">

      <div class="content">
         <h3>Elevate<span>.Self</span></h3>
         <h5 class="heading">Education <span>Platform</span></h5>
         <a href="textbook.php" class="btn">Dive In</a>
         
      </div>

      <div class="image">
         <img src="images/html.PNG" alt="">
      </div>

   </div>

</section>

<!-- home section ends -->

<div class="divide_home">
   <div>
      <!-- <span class="count-value" data-count="100">0</span> -->
      <!-- <p>Students</p> -->
   </div>

</div>

<!-- about section starts  -->

<section class="about" id="about">

   <div class="row">

      <div class="image" style="margin: 4rem; padding-right: 2rem;">
         <img src="images/code.PNG" alt="">
      </div>

      <div class="content">
         <h3 class="heading">why choose <span>us?</span></h3>
         <h1 class="heading">Education Platform for IT students <span>Built By students</span></h1>
         <h4 class="heading">Up-to-Date <span>Resources</span></h4>
        
      </div>


      </div>
   </div>

</section>

<!-- about section ends -->

<!-- couter section stars  -->

<section class="count">

   <div class="box-container">

      <div class="box">
         <i class="fas fa-graduation-cap"></i>
         <div class="content">
            <h3>25</h3>
            <p>textbooks</p>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-user-graduate"></i>
         <div class="content">
            <h3>5 UJ</h3>
            <p>students</p>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-chalkboard-user"></i>
         <div class="content">
            <h3>10</h3>
            <p>resources</p>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-face-smile"></i>
         <div class="content">
            <h3>Education</h3>
            <p>satisfaction</p>
         </div>
      </div>

   </div>

</section>

<!-- couter section ends -->

<!-- courses section starts  -->

<section class="courses" id="courses">

   <h1 class="heading">our <span>Textbooks</span></h1>

   <div class="swiper course-slider">

      <div class="swiper-wrapper">

         <div class="swiper-slide slide">
            <img src="images/python.png" style="opacity: 0.9;"alt="">
            <h3>Python</h3>
            <p>Find our Textbooks and Related articles </p>
            <a href="textbook.php" class="btn">Dive In</a>
         </div>

         <div class="swiper-slide slide">
            <img src="images/js.png"style="opacity: 0.9;" alt="">
            <h3>Javascript</h3>
            <p>Find our Textbooks and Related articles </p>
            <a href="textbook.php" class="btn">Dive In</a>
         </div>

         <div class="swiper-slide slide">
            <img src="images/new.png" alt="">
            <h3>Web developement</h3>
            <p>Find our Textbooks and Related articles </p>
            <a href="textbook.php" class="btn">Dive In</a>
         </div>

         <div class="swiper-slide slide">
            <img src="images/hack.PNG"  alt="">
            <h3>Cybersecurity</h3>
            <p>Find our Textbooks and Related articles </p>
            <a href="textbook.php" class="btn">Dive In</a>
         </div>

         <div class="swiper-slide slide">
            <img src="images/D-S.PNG" alt="">
            <h3>Data science</h3>
            <p>Find our Textbooks and Related articles </p>
            <a href="textbook.php" class="btn">Dive In</a>
         </div>

         <div class="swiper-slide slide">
            <img src="images/process.PNG" alt="">
            <h3>Software Engineering</h3>
            <p>Find our Textbooks and Related articles </p>
            <a href="textbook.php" class="btn">Dive In</a>
         </div>

      </div>

      <div class="swiper-pagination"></div>

   </div>

</section>

<!-- courses section ends -->

<!-- resources section starts  -->

<section class="reviews" id="reviews">

   <h1 class="heading"> student's <span>resources</span></h1>

   <div class="swiper reviews-slider">

      <div class="swiper-wrapper">

         <div class="swiper-slide slide">
            <h3 class="heading1">Developer Environments</h3>
               <ul class="new_list">
                  <li><a href="https://code.visualstudio.com/docs" class="new_link">Get Started with VS Code</a></li>
                  <li><a href="https://docs.microsoft.com/en-us/windows/wsl/" class="new_link">Windows Subsystem for Linux</a></li>
                  <li><a href="https://www.jetbrains.com/pycharm/features/" class="new_link">Getting started with PyCharm</a></li>
                  <li><a href="https://www.jetbrains.com/phpstorm/features/" class="new_link">Getting started with PhpStorm</a></li>
                  <li><a href="https://www.jetbrains.com/webstorm/features/" class="new_link">Webstorm for Web developement</a>
               </ul>

         </div>

         <div class="swiper-slide slide">
            <h3 class="heading1">Student Financing</h3>
                  <ul class="new_list">
                     <li><a href="https://www.fundi.co.za/" class="new_link">Fundi Loans</a></li>
                     <li><a href="https://www.dhet.gov.za/SitePages/NSF.aspx" class="new_link">National Skills Fund (NSF)</a></li>
                     <li><a href="https://www.uj.ac.za/faculties/college-of-business-and-economics/schools/school-of-tourism-and-hospitality-sth/school-of-tourism-and-hospitality-bursaries-and-financing/" class="new_link">UJ Bursaries & Funding</a></li>
                     <li><a href="https://www.studentroom.co.za/" class="new_link">Student Room - Busaries</a></li>
                     <li><a href="https://www.youthopportunitieshub.com/" class="new_link">Youth Opportunities Hub</a></li>
                     <li><a href="http://www.nsfas.org.za/content" class="new_link">Nsfas Application</a></li>
                  </ul>

         </div>

         <div class="swiper-slide slide">
            <h3 class="heading1">Github Repositories</h3>
               <ul class="new_list">
                  <li><a href="https://github.com/codecrafters-io/build-your-own-x" class="new_link">Build your own ___ project</a></li>
                  <li><a href="https://github.com/TheAlgorithms/Python" class="new_link">The Algorithms - Python</a></li>
                  <li><a href="https://github.com/airbnb/javascript" class="new_link">Javascript Style Guide</a></li>
                  <li><a href="https://github.com/anu0012/awesome-computer-science-opportunities?ref=producthunt" class="new_link">List of opportunities for Computer Science students</a></li>
                  <li><a href="https://github.com/ryanmcdermott/clean-code-javascript" class="new_link"> Clean Code concepts adapted for JavaScript</a></li>
                  <li><a href="https://github.com/ziadoz/awesome-php" class="new_link">PHP libraries & Resource</a>
               </ul>
            <div class="user">
               
            </div>
         </div>

         <div class="swiper-slide slide">
            <h3 class="heading1">Student Freebies</h3>
                             <ul class="new_list">
                    <li><a href="https://bootstrapstudio.io/student-pack" class="new_link">Free license for Bootstrap Studio</a></li>
                    <li><a href="https://www.jetbrains.com/community/education/?authMethod=github#students" class="new_link">Free Jetrains subscription for students</a></li>
                    <li><a href="https://azure.microsoft.com/en-us/free/students/?WT.mc_id=academic-9938-cxa" class="new_link">Free access to 25+ Microsoft Azure cloud services</a></li>
                     <li><a href="https://www.jetbrains.com/community/education/?authMethod=github#students" class="new_link">Free access to Jetbrains PhpStorm</a></li>
                  </ul>
            <div class="user">
               
            </div>
         </div>

         <div class="swiper-slide slide">
            <h3 class="heading1">Developer Environments</h3>
               <ul class="new_list">
                <li><a href="https://code.visualstudio.com/docs" class="new_link">Get Started with VS Code</a></li>
                <li><a href="https://docs.microsoft.com/en-us/windows/wsl/" class="new_link">Windows Subsystem for Linux</a></li>
                <li><a href="https://www.jetbrains.com/pycharm/features/" class="new_link">Getting started with PyCharm</a></li>
                <li><a href="https://www.jetbrains.com/phpstorm/features/" class="new_link">Getting started with PhpStorm</a></li>
                <li><a href="https://www.jetbrains.com/webstorm/features/" class="new_link">Webstorm for Web developement</a></li>
          
               </ul>
            <div class="user">

            </div>
         </div>

         <!-- <div class="swiper-slide slide">
            <h3 class="heading1">Developer Environments</h3>
                             <ul class="new_list">
                    <li><a href="https://github.com/codecrafters-io/build-your-own-x" class="new_link">Build your own ___ project</a><ul>
                    <li><a href="https://github.com/codecrafters-io/build-your-own-x" class="new_link">Build your own ___ project</a></li>
                    <li><a href="https://github.com/codecrafters-io/build-your-own-x" class="new_link">Build your own ___ project</a></li>
                  </ul>
            <div class="user">
               
            </div> -->
         </div>

         

      </div>

      

      <div class="swiper-pagination"></div>

      

   </div>
   <a href="resources.php" class="btn-1" >Visit these Resources</a>
</section>

<!-- reviews section ends -->

<!-- teachers section starts  -->

<section class="teachers" id="teachers">

   <h1 class="heading">Student <span>tutors</span></h1>

   <div class="swiper teachers-slider">

      <div class="swiper-wrapper">

         <div class="swiper-slide slide">
            <img src="images/gary.jpg" alt="">
            <div class="share">
               <a href="#" style="background-color:blue">
                  <h2>F</h2>
                  
               </a>
               <a href="https://twitter.com/" style="background-color:rgb(0, 174, 255)">
                  <h2>T</h2>
                  
               </a>
               <a href="#" style="background-color:rgb(0, 255, 42)">
                  <h2>W</h2>
                  
               </a>
               <a href="https://github.com/garyrmeadeTettey/DSW_Group_Project" style="background-color:rgb(202, 9, 209)">
                  <h2>G</h2>
                  
               </a>
            </div>
            <h3>Gary-Ross Meade Tettey</h3>
         </div>
         
         <div class="swiper-slide slide">
            <img src="images/luyanda.jpg" alt="">
            <div class="share">
               <a href="#" style="background-color:blue">
                  <h2>F</h2>
                  
               </a>
               <a href="https://twitter.com/" style="background-color:rgb(0, 174, 255)">
                  <h2>T</h2>
                  
               </a>
               <a href="#" style="background-color:rgb(0, 255, 42)">
                  <h2>W</h2>
                  
               </a>
               <a href="https://github.com/garyrmeadeTettey/DSW_Group_Project" style="background-color:rgb(202, 9, 209)">
                  <h2>G</h2>
                  
               </a>
            </div>
            <h3>Luyanda Nkonyeni</h3>
         </div>

         <div class="swiper-slide slide">
            <img src="images/liam.jpg" alt="">
            <div class="share">
               <a href="#" style="background-color:blue">
                  <h2>F</h2>
                  
               </a>
               <a href="https://twitter.com/" style="background-color:rgb(0, 174, 255)">
                  <h2>T</h2>
                  
               </a>
               <a href="#" style="background-color:rgb(0, 255, 42)">
                  <h2>W</h2>
                  
               </a>
               <a href="https://github.com/garyrmeadeTettey/DSW_Group_Project" style="background-color:rgb(202, 9, 209)">
                  <h2>G</h2>
                  
               </a>>
            </div>
            <h3>Liam Sobryan Maritz</h3>
         </div>

         <div class="swiper-slide slide">
            <img src="images/zona.jpg" alt="">
            <div class="share">
               <a href="#" style="background-color:blue">
                  <h2>F</h2>
                  
               </a>
               <a href="https://twitter.com/" style="background-color:rgb(0, 174, 255)">
                  <h2>T</h2>
                  
               </a>
               <a href="#" style="background-color:rgb(0, 255, 42)">
                  <h2>W</h2>
                  
               </a>
               <a href="https://github.com/garyrmeadeTettey/DSW_Group_Project" style="background-color:rgb(202, 9, 209)">
                  <h2>G</h2>
                  
               </a>
            </div>
            <h3>Zizile Ezona Mbangi</h3>
         </div>

         <div class="swiper-slide slide">
            <img src="images/lesego.jpg" alt="">
            <div class="share">
               <a href="#" style="background-color:blue">
                  <h2>F</h2>
                  
               </a>
               <a href="https://twitter.com/" style="background-color:rgb(0, 174, 255)">
                  <h2>T</h2>
                  
               </a>
               <a href="#" style="background-color:rgb(0, 255, 42)">
                  <h2>W</h2>
                  
               </a>
               <a href="https://github.com/garyrmeadeTettey/DSW_Group_Project" style="background-color:rgb(202, 9, 209)">
                  <h2>G</h2>
                  
               </a>
            </div>
            <h3>Lesego Leorapetse</h3>
         </div>

         <div class="swiper-slide slide">
            <img src="images/sample.jpg" alt="">
            <div class="share">
               <a href="#" style="background-color:blue">
                  <h2>F</h2>
                  
               </a>
               <a href="#" class="fab fa-twitter"></a>
               <a href="#" class="fab fa-instagram"></a>
               <a href="#" class="fab fa-linkedin"></a>
            </div>
            <h3>Group member 6</h3>
         </div>

      </div>

      <div class="swiper-pagination"></div>

   </div>

</section>

<!-- teachers section ends -->



<!-- contact section starts  -->

<section class="contact" id="contact">

   <h1 class="heading"><span>contact</span> us</h1>

   <div class="row">

      <div class="image">
         <img src="images/coding.PNG" alt="">
      </div>

      <form action="" method="post">
         <span>your name</span>
         <input type="text" required placeholder="enter your full name" maxlength="50" name="name" class="box">
         <span>your email</span>
         <input type="email" required placeholder="enter your valie email" maxlength="50" name="email" class="box">
         <span>your number</span>
         <input type="number" required placeholder="enter your valie number" max="9999999999" min="0" name="number" class="box" onkeypress="if(this.value.length == 10) return false;">
         <span>select course</span>
         <select name="couses" class="box" required>
            <option value="" disabled selected>select the course --</option>
            <option value="web developement">web developement</option>
            <option value="science and biology">Blockchain</option>
            <option value="engineering">engineering</option>
            <option value="digital marketing">digital marketing</option>
            <option value="graphic design">graphic design</option>
            <option value="teaching">teaching</option>
            <option value="social studies">social studies</option>
            <option value="data analysis">data analysis</option>
            <option value="artificial intelligence">artificial intelligence</option>
         </select>
         <span>select gender</span>
         <div class="radio">
            <input type="radio" name="gender" value="male" id="male">
            <label for="male">male</label>
            <input type="radio" name="gender" value="female" id="female">
            <label for="female">female</label>
         </div>
         <input type="submit" value="send message" class="btn" name="send">
      </form>

   </div>

</section>

<!-- contact section ends -->

<!-- footer section starts  -->

<footer class="footer">

   <section>

      <div class="share">
         <a href="#" class="fab fa-facebook-f"></a>
         <a href="#" class="fab fa-twitter"></a>
         <a href="#" class="fab fa-linkedin"></a>
         <a href="#" class="fab fa-instagram"></a>
         <a href="#" class="fab fa-youtube"></a>
      </div>

      <div class="credit">&copy; copyright @ 2022 by <span>Elevate.Self</span> | no rights reserved!</div>

   </section>

</footer>

<!-- footer section ends -->















<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>