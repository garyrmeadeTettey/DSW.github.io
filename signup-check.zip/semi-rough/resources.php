<?php
   include_once("../db_connect.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elevate.Self</title>

    <link rel="stylesheet" href="css/style.css">

</head>
<body>

    <div class="new_body">
            <!-- header section starts  -->

        <header class="header">

        <section class="flex">
 
       <a href="#home" class="logo">Elevate.Self</a>
 
       <nav class="navbar">
          <a href="index.php">home</a>
          <a href="index.php#about">about</a>
          <a href="textbook.php">Textbooks</a>
          <a href="index.php#teachers">Tutors</a>
          <a href="resources.php">Resources</a>
          <a href="index.php#contact">contact</a>
          <a href="logout.php">Logout</a>
       </nav>
 
       <div id="menu-btn" class="fas fa-bars"></div>
 
    </section>
 
    </header>
 
 <!-- header section ends -->


    <section class="reviews" id="reviews">

        <h1 class="heading"> student's <span>resources</span></h1>
     
        <div class="swiper reviews-slider">
     
           <div class="swiper-wrapper">
     
              <div class="swiper-slide slide">
                 <h3 class="heading1">Developer Environments</h3>
                 <ul class="new_list">
                    <li><a href="https://code.visualstudio.com/docs" class="new_link">Get Started with VS Code</a></li>
                    <li><a href="https://docs.microsoft.com/en-us/windows/wsl/" class="new_link">Windows Subsystem for Linux</a></li>
                    <li><a href="https://www.jetbrains.com/pycharm/features/" class="new_link">Getting started with PyCharm</a></li>
                    <li><a href="https://www.jetbrains.com/phpstorm/features/" class="new_link">Getting started with PhpStorm</a></li>
                    <li><a href="https://www.jetbrains.com/webstorm/features/" class="new_link">Webstorm for Web developement</a></li>

                  </ul>
                 <div class="user">

                    </div>
                 </div>
              </div>
     
              <div class="swiper-slide slide">
                 <h3 class="heading1">Student Financing</h3>
                 <ul class="new_list">
                    <li><a href="https://www.fundi.co.za/" class="new_link">Fundi Loans</a></li>
                    <li><a href="https://www.dhet.gov.za/SitePages/NSF.aspx" class="new_link">National Skills Fund (NSF)</a></li>
                    <li><a href="https://www.uj.ac.za/faculties/college-of-business-and-economics/schools/school-of-tourism-and-hospitality-sth/school-of-tourism-and-hospitality-bursaries-and-financing/" class="new_link">UJ Bursaries & Funding</a></li>
                    <li><a href="https://www.studentroom.co.za/" class="new_link">Student Room - Busaries</a></li>
                    <li><a href="https://www.youthopportunitieshub.com/" class="new_link">Youth Opportunities Hub</a></li>
                    <li><a href="http://www.nsfas.org.za/content" class="new_link">Nsfas Application</a></li>
                  </ul>
                 <div class="user">
                    
                 </div>
              </div>
     
              <div class="swiper-slide slide">
                 <h3 class="heading1">Github Repositories</h3>
                 <ul class="new_list">
                    <li><a href="https://github.com/codecrafters-io/build-your-own-x" class="new_link">Build your own ___ project</a></li>
                    <li><a href="https://github.com/TheAlgorithms/Python" class="new_link">The Algorithms - Python</a></li>
                    <li><a href="https://github.com/airbnb/javascript" class="new_link">Javascript Style Guide</a></li>
                    <li><a href="https://github.com/anu0012/awesome-computer-science-opportunities?ref=producthunt" class="new_link">List of opportunities for Computer Science students</a></li>
                    <li><a href="https://github.com/ryanmcdermott/clean-code-javascript" class="new_link"> Clean Code concepts adapted for JavaScript</a></li>
                    <li><a href="https://github.com/ziadoz/awesome-php" class="new_link">PHP libraries & Resource</a></li>
                  </ul>
                </li>
                 <div class="user">

                 </div>
              </div>
     
              <div class="swiper-slide slide">
                 <h3 class="heading1">Guided Projects</h3>
                 <ul class="new_list">
                    <li><a href="https://github.com/nchapman95/Guided-Projects/tree/master/Guided%20Project_%20Exploring%20Hacker%20News%20Posts" class="new_link">Exploring Hacker News Posts</a></li>
                    <li><a href="https://github.com/nchapman95/Guided-Projects/tree/master/Guided%20Project_%20Visualizing%20Earnings%20Based%20On%20College%20Majors" class="new_link">Visualizing Earnings Based On College Majors</a></li>
                    <li><a href="https://github.com/nchapman95/Guided-Projects/tree/master/Guided%20Project_%20Investigating%20Airplane%20Accidents" class="new_link">Investigating Airplane Accidents</a></li>
                    <li><a href="https://github.com/nchapman95/Guided-Projects/tree/master/Guided%20Project_%20Predicting%20House%20Sale%20Prices" class="new_link">Predicting House Sale Prices</a></li>
                    <li><a href="https://github.com/nchapman95/Guided-Projects/tree/master/Guided%20Project_%20Exploring%20Ebay%20Car%20Sales%20Data" class="new_link">Exploring Online Car Sales Data</a></li>
                    <li><a href="https://github.com/nchapman95/Guided-Projects/tree/master/Guided%20Project_%20Creating%20a%20Kaggle%20Workflow" class="new_link">Creating a Kaggle Workflow</a></li>
                  </ul>
                 <div class="user">

                 </div>
              </div>
     
              <div class="swiper-slide slide">
                <h3 class="heading1">Student Freebies</h3>
                                 <ul class="new_list">
                        <li><a href="https://bootstrapstudio.io/student-pack" class="new_link">Free license for Bootstrap Studio</a></li>
                        <li><a href="https://www.jetbrains.com/community/education/?authMethod=github#students" class="new_link">Free Jetrains subscription for students</a></li>
                        <li><a href="https://azure.microsoft.com/en-us/free/students/?WT.mc_id=academic-9938-cxa" class="new_link">Free access to 25+ Microsoft Azure cloud services</a></li>
                         <li><a href="https://www.jetbrains.com/community/education/?authMethod=github#students" class="new_link">Free access to Jetbrains PhpStorm</a></li>
                      </ul>
                <div class="user">
                   
                </div>
             </div>
     
              <!-- <div class="swiper-slide slide">
                 <h3 class="heading1">Developer Environments</h3>
                 <ul class="new_list">
                    <li>List Item</li>
                        <li>List Item<ul>
                    <li>List Item</li>

                    <li>List Item</li>
                    <li>List Item</li>
                    <li>List Item</li>
                  </ul>
                <div class="user">

                </div>
                 </div>
              </div> -->
     
              
     
           </div>
     
           
     
           <div class="swiper-pagination"></div>
     
           
     
        </div>
        <a href="resources.php" class="btn-1" >Visit these Resources</a>
     </section>
     
     <!-- reviews section ends -->
    </div>

        <!-- footer section starts  -->

    <footer class="footer">

    <section>
 
       <div class="share">
          <a href="#" class="fab fa-facebook-f"></a>
          <a href="#" class="fab fa-twitter"></a>
          <a href="#" class="fab fa-linkedin"></a>
          <a href="#" class="fab fa-instagram"></a>
          <a href="#" class="fab fa-youtube"></a>
       </div>
 
       <div class="credit">&copy; copyright @ 2022 by <span>Elevate.Self</span> | no rights reserved!</div>
 
    </section>
 
    </footer>
 
 <!-- footer section ends -->  
</body>
</html>