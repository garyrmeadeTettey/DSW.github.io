<?php
   include_once("../db_connect.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="css/style.css">

</head>
<body>

    <div class="new_body">
            <!-- header section starts  -->

        <header class="header">

        <section class="flex">
 
       <a href="#home" class="logo">Elevate.Self</a>
 
       <nav class="navbar">
        <a href="index.php">home</a>
        <a href="index.php#about">about</a>
        <a href="textbook.php">Textbooks</a>
        <a href="index.php#teachers">Tutors</a>
        <a href="resources.php">Resources</a>
        <a href="index.php#contact">contact</a>
        <a href="logout.php">Logout</a>
       </nav>
 
       <div id="menu-btn" class="fas fa-bars"></div>
 
    </section>
 
    </header>
 
 <!-- header section ends -->


    <section class="reviews" id="reviews">

        <h1 class="heading"> Text<span>Books</span></h1>
     
        <div class="swiper reviews-slider">
     
           <div class="swiper-wrapper-1">
     
              <div class="swiper-slide slide">
                 <h3 class="heading1">Python</h3>
                 
                <ul class="new_list">
                    <ul class="new_list-1" >
                        <li ><a href="https://za1lib.org/book/5458211/fed892" class="new_link">Python 3: Exercise for beginers</a></li>
                        <li><a href="https://za1lib.org/book/5397996/6aa85e" class="new_link">Python Projects for Beginners</a></li>
                        <li><a href="https://za1lib.org/book/5396066/b413f1" class="new_link">Python for Finance Cookbook</a></li>
                        <li><a href="https://za1lib.org/book/11000183/f5454f" class="new_link">Competitive Programming in Python</a></li>
                        <li><a href="https://za1lib.org/book/5557856/e46648 " class="new_link">Python Automation Cookbook</a></li>
                    </ul>
                </ul>

                 
              </div>
     
              <div class="swiper-slide slide">
                 <h3 class="heading1">JavaScript</h3>
                 <ul class="new_list-1">
                    <ul class="new_list" >
                        <li ><a href="https://za1lib.org/book/5533416/34944c" class="new_link">JavaScript: The Definitive Guide</a></li>
                        <li><a href="https://za1lib.org/book/5412325/2f13c8" class="new_link">Clean Code in JavaScript</a></li>
                        <li><a href="https://za1lib.org/book/5411337/2da096" class="new_link">Professional JavaScript for web developers</a></li>
                        <li><a href="https://za1lib.org/book/5412326/d63dab" class="new_link">Hands On JavaScript</a></li>
                        <li><a href="https://za1lib.org/book/11608546/77ffd6" class="new_link">JavaScript for impatient programmers</a></li>
                    </ul>
                    
              </div>
     
              <div class="swiper-slide slide">
                 <h3 class="heading1">Web developement</h3>
                 <ul class="new_list-1">
                    <ul class="new_list" >
                        <li ><a href="https://za1lib.org/book/5517597/84baa4" class="new_link">Responsive Web Design with HTML5 and CSS</a></li>
                        <li><a href="https://za1lib.org/book/3658054/eb3c50" class="new_link">Flask Web Development</a></li>
                        <li><a href="https://za1lib.org/book/2885521/e24cfb" class="new_link">Learning React</a></li>
                        <li><a href="https://za1lib.org/book/3593541/254d30" class="new_link">Designing Web APIs</a></li>
                        <li><a href="https://za1lib.org/book/5685813/9e9f08" class="new_link">Full-Stack React Projects</a></li>
                    </ul>
              </div>
     
              <div class="swiper-slide slide">
                 <h3 class="heading1">Cybersecurity</h3>
                 <ul class="new_list-1">
                    <ul class="new_list" >
                        <li ><a href="https://za1lib.org/book/5591951/605ae2" class="new_link">Computer Programming & Cyber Security for Beginners</a></li>
                        <li><a href="https://za1lib.org/book/3632745/69e83b" class="new_link">Cybersecurity-Attack and Defense Strategies</a></li>
                        <li><a href="https://za1lib.org/book/5248858/af8fdf" class="new_link">Python for Finance Cookbook</a></li>
                        <li><a href="https://za1lib.org/book/11000183/f5454f" class="new_link">Cybersecurity Blue Team Toolkit</a></li>
                        <li><a href="https://za1lib.org/book/3589379/f834c9" class="new_link">Cybersecurity Essentials</a></li>
                    </ul>
              </div>
     
              <div class="swiper-slide slide">
                 <h3 class="heading1">Software engineering</h3>
                 <ul class="new_list-1">
                    <ul class="new_list" >
                        <li ><a href="https://za1lib.org/book/5407664/01e173" class="new_link">Fundamentals of Software Architecture</a></li>
                        <li><a href="https://za1lib.org/book/5345121/b6b3c1" class="new_link">Software Engineering at Google</a></li>
                        <li><a href="https://za1lib.org/book/3655462/b894c7" class="new_link">Hands-On Software Engineering with Python</a></li>
                        <li><a href="https://za1lib.org/book/3329712/99af9c" class="new_link">How software works</a></li>
                        <li><a href="https://za1lib.org/book/511011/b43b03" class="new_link">Embedded Hardware</a></li>
                    </ul>
              </div>
     
              <div class="swiper-slide slide">
                 <h3 class="heading1">Data Science</h3>
                 <ul class="new_list-1">
                    <ul class="new_list" >
                        <li ><a href="https://za1lib.org/book/4989630/29a81f" class="new_link">Data Science from Scratch</a></li>
                        <li><a href="https://za1lib.org/book/2850613/b8f661" class="new_link">R for Data Science</a></li>
                        <li><a href="https://za1lib.org/book/3015365/ea429c" class="new_link">The Art of Data Science</a></li>
                        <li><a href="https://za1lib.org/book/2739951/aeeb06" class="new_link">Introducing Data Science</a></li>
                        <li><a href="https://za1lib.org/book/3504110/25c7a7" class="new_link">Practical Web Scraping for Data Science</a></li>
                    </ul>
              </div>
     
              
     
           </div>
     
           
     
           <div class="swiper-pagination"></div>
     
           
     
        </div>
    
     </section>
     
     <!-- reviews section ends -->
    </div>

        <!-- footer section starts  -->

    <footer class="footer">

    <section>
 
       <div class="share">
          <a href="#" class="fab fa-facebook-f"></a>
          <a href="#" class="fab fa-twitter"></a>
          <a href="#" class="fab fa-linkedin"></a>
          <a href="#" class="fab fa-instagram"></a>
          <a href="#" class="fab fa-youtube"></a>
       </div>
 
       <div class="credit">&copy; copyright @ 2022 by <span>Elevate.Self</span> | no rights reserved!</div>
 
    </section>
 
    </footer>
 
 <!-- footer section ends -->  
</body>
</html>